document.getElementById("signupForm").addEventListener("submit", function (e) {
    e.preventDefault();
  
    // Retrieve values
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
  
    // Store the values in localStorage
    const userDetails = {
      username,
      email,
      password,
    };
  
    localStorage.setItem("userDetails", JSON.stringify(userDetails));
  
    // Show success message
    const statusMessage = document.getElementById("status-message");
    statusMessage.textContent = "Registration successful!";
    statusMessage.style.color = "lightgreen";
  
    // Clear the form fields
    document.getElementById("signupForm").reset();
  });
  